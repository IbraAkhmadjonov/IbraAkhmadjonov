enum TypeOfComboEnum{
  dokonlar,
  agentlar,
  tovarlar,
  narx_turlari,
  yuk_beruvchilar,
  omborlar,
  mahsulot_turlari,
  sana
}
