import 'package:get/get.dart';

class Dimensions {
  static double screenHeight = Get.context!.height;  // 844.0
  static double screenWidth = Get.context!.width;   // 390.0

  static double heightMainBord = screenHeight / 1.5;

  static double mainCardViewHeight = screenHeight / 6;
  static double mainCardViewWidth = screenWidth / 3;

  static double height10 = screenHeight / 84.4;
  static double height15 = screenHeight / 56.27;
  static double height20 = screenHeight / 42.2;

  static double width10 = screenHeight / 84.4;
  static double width15 = screenHeight / 56.27;
  static double width20 = screenHeight / 42.2;
  static double width30 = screenHeight / 28.13;

  static double font16 = screenHeight / 52.75;
  static double font12 = screenHeight / 70.34;
  static double font20 = screenHeight / 42.2;
  static double font26 = screenHeight / 32.46;

  static double radius15 = screenHeight / 56.27;
  static double radius20 = screenHeight / 42.2;
  static double radius30 = screenHeight / 28.13;

  static double iconSize24 = screenHeight / 35.17;
  static double iconSize16 = screenHeight / 52.75;

  // splash screen dimensions
  static double splashImage = screenHeight/3.38;


}