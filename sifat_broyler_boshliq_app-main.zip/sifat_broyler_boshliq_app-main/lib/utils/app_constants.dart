class AppConstants {
  static const String APP_NAME = "Sifat Broyler Admin App";
  static const int APP_VERSION = 1;

  static const String BASE_URL = "https://www.sifat-broyler.uz/app_admin";

  static const String URL_LOGIN = "/login.php";
  static const String URL_INSERT_SAVOL = "/in_savol.php";
  static const String URL_GET_JAVOB = "/get_javob.php";
  static const String URL_GET_DOKONLAR = "/get_dokonlar.php";
static const String URL_GET_YUK_BERUVCHILAR = "/get_yuk_beruvchilar.php";
  static const String URL_GET_AGENTLAR = "/get_agentlar.php";
  static const String URL_GET_TOVARLAR = "/get_tovarlar.php";
  static const String URL_GET_GRUPPALAR = "/get_gruppa.php";
  static const String URL_GET_DOLLAR_KURSI = "/get_kurs.php";

  static const String USER_ID = "user_id";
  static const String USER_PHONE = "user_phone";
  static const String USER_PASSWORD = "user_password";
  static const String USER_FIO  = "user_fio";

  static const String KEY_QARZDORLIK  = "39";
  static const String KEY_YUK_TOLOV_SAQLASH  = "40";
  static const String KEY_MIJOZ_TOLOVI_SAQLASH  = "41";
  static const String KEY_TOVAR_OZGARTIRISH  = "42";

  static const String KEY_KURS_OZGARTIRISH  = "43";

}