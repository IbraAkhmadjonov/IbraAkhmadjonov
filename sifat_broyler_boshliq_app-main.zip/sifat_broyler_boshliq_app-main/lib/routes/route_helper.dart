import 'package:boshliq_app/pages/home/home_page.dart';
import 'package:boshliq_app/pages/login/login_page.dart';
import 'package:boshliq_app/pages/sozlama/sozlama_page.dart';
import 'package:boshliq_app/pages/splash/splash_page.dart';
import 'package:boshliq_app/pages/tovarlar/gruppalar_page.dart';
import 'package:boshliq_app/pages/tovarlar/tovarlar_page.dart';
import 'package:get/get.dart';

class RouteHelper {

  static const String splashPage = "/splash-page";
  static const String initial = "/";
  static const String loginPage = "/login";
  static const String sozlamaPage = "/sozlama";
  static const String gruppalarPage = "/gruppa";
  static const String tovarlarPage = "/tovarlar";


  static String getSplashPage() => '$splashPage';
  static String getInitial() => '$initial';
  static String getLoginPage() => '$loginPage';
  static String getSozlamaPage() => '$sozlamaPage';
  static String getGruppaPage() => '$gruppalarPage';
  static String getTovarlarPage(String gruppaId, String nomi) => '$tovarlarPage?gruppaId=$gruppaId&nomi=$nomi';

  // static String getPopularFood(int pageId, String page) => '$popularFood?pageId=$pageId&page=$page';
  // static String getRecommendedFood(int pageId, String page) => '$recommendedFood?pageId=$pageId&page=$page';

  static List<GetPage> routes = [
    GetPage(name: initial, page: () => HomePage(), transition: Transition.fade),
    GetPage(name: loginPage, page: () => LoginPage(), transition: Transition.fade),
    GetPage(name: splashPage, page: () => SplashScreen(), transition: Transition.fade),
    GetPage(name: sozlamaPage, page: () => SozlamaPage(), transition: Transition.fade),
    GetPage(name: gruppalarPage, page: () => GruppalarPage(), transition: Transition.fade),
    GetPage(
        name: tovarlarPage,
        page: () {
          var gruppaId = Get.parameters['gruppaId'];
          var nomi = Get.parameters['nomi'];
          return TovarlarPage(gruppaId: gruppaId!, gruppaNomi: nomi!);
        },
        transition: Transition.fadeIn),
    // GetPage(
    //     name: recommendedFood,
    //     page: () {
    //       var pageId = Get.parameters['pageId'];
    //       var page = Get.parameters['page'];
    //
    //       return RecommendedFoodDetail(pageId: int.parse(pageId!), page: page!);
    //     },
    //     transition: Transition.fadeIn),
    //
    // GetPage(
    //     name: cartPage,
    //     page: (){
    //       return CartPage();
    //     },
    //     transition: Transition.fadeIn
    // ),
    //
    // GetPage(
    //     name: addAddress,
    //     page: (){
    //       return AddAddressPage();
    //     },
    //     transition: Transition.fadeIn
    // )
  ];
}
