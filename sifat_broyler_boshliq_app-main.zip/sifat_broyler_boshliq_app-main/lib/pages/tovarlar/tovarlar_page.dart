import 'package:boshliq_app/base/show_custom_snackbar.dart';
import 'package:boshliq_app/controllers/all_data_controller.dart';
import 'package:boshliq_app/models/gruppa_model.dart';
import 'package:boshliq_app/models/tovar_model.dart';
import 'package:boshliq_app/pages/home/dialogs/dialog_tovar_edit.dart';
import 'package:boshliq_app/routes/route_helper.dart';
import 'package:boshliq_app/utils/app_constants.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/widgets/app_bar_widget.dart';
import 'package:boshliq_app/widgets/app_text_field.dart';
import 'package:boshliq_app/widgets/big_text.dart';
import 'package:boshliq_app/widgets/small_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:money_formatter/money_formatter.dart';

class TovarlarPage extends StatefulWidget {
  final String gruppaId;
  final String gruppaNomi;

  const TovarlarPage({Key? key, required this.gruppaId, required this.gruppaNomi}) : super(key: key);

  @override
  State<TovarlarPage> createState() => _TovarlarPageState();
}

class _TovarlarPageState extends State<TovarlarPage> {

  var searchController = TextEditingController();

  void filterSearchResults(String query) {
    List<TovarModel> dummySearchList = <TovarModel>[];
    dummySearchList.addAll(Get.find<AllDataController>().tovarlarList);
    if (query.isNotEmpty) {
      List<TovarModel> dummyListData = <TovarModel>[];
      dummySearchList.forEach((item) {
        if (item.nomi!.toUpperCase().contains(query.toUpperCase())) {
          dummyListData.add(item);
        }
      });
      setState(() {
        gruppaList.clear();
        gruppaList.addAll(dummyListData);
      });
      return;
    } else {
      setState(() {
        gruppaList.clear();
        gruppaList.addAll(Get.find<AllDataController>().tovarlarList);
      });
    }
  }

  List<TovarModel> gruppaList = <TovarModel>[];


  @override
  void initState(){
    gruppaList.addAll(Get.find<AllDataController>().tovarlarList.where((element) => element.brend_id == widget.gruppaId));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: appBarWidget(context,"${widget.gruppaNomi} tovarlar ro'yhati",AppColors.mainColor),
        body: GetBuilder<AllDataController>(builder: (allDataController){
          return Column(
              children: [
                SizedBox(height: Dimensions.height10,),
                AppTextField(
                  textController: searchController,
                  hintText: "Qidirish",
                  icon: Icons.search,
                  onTextChanged: (text){
                    filterSearchResults(text);
                  },
                ),
                SizedBox(height: Dimensions.height10,),
                Expanded(
                  child: ListView.builder(
                    padding: EdgeInsets.all(Dimensions.height20),
                    shrinkWrap: true,
                    itemCount:gruppaList.length,
                    physics: BouncingScrollPhysics(),
                    itemBuilder: (context,index){
                      return GestureDetector(
                        onTap: (){
                          TovarModel model = gruppaList[index];
                          // showCustomSnackbar(model.toJson().toString());
                          showDialog(context: context,
                              barrierDismissible: false,
                              builder: (context){
                                return DialogTovarEdit(tovarModel: model,);
                              });
                        },
                        child: Container(
                          height: Dimensions.height15*3,
                          margin: EdgeInsets.only(bottom: Dimensions.height20),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(Dimensions.radius20/2),
                            color: AppColors.mainColor,
                          ),
                          child: Row(
                            children: [
                              SizedBox(width: Dimensions.width20,),
                              SmallText(text: (index+1).toString(),
                                size: Dimensions.font20,
                                color: Colors.black,
                              ),
                              SizedBox(width: Dimensions.width20,),
                              SmallText(text: gruppaList[index].nomi!,
                                size: Dimensions.font20,
                                color: Colors.black,
                              ),
                              SizedBox(width: Dimensions.width20,),
                              Expanded(
                                child: SmallText(text: MoneyFormatter(amount: double.parse(gruppaList[index].narxi ?? "0"), settings: MoneyFormatterSettings(thousandSeparator: ' ',)).output.nonSymbol,
                                  size: Dimensions.font20,
                                  color: Colors.black,
                                  textAlign: TextAlign.right,
                                ),
                              ),
                              SizedBox(width: Dimensions.width20,),
                            ],
                          ),
                        ),
                      );

                    },
                  ),
                ),
              ]
          );
        }),
      ),
    );
  }
}
