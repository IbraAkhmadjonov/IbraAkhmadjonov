import 'package:boshliq_app/base/show_custom_snackbar.dart';
import 'package:boshliq_app/controllers/all_data_controller.dart';
import 'package:boshliq_app/models/gruppa_model.dart';
import 'package:boshliq_app/routes/route_helper.dart';
import 'package:boshliq_app/utils/app_constants.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/widgets/app_bar_widget.dart';
import 'package:boshliq_app/widgets/app_text_field.dart';
import 'package:boshliq_app/widgets/big_text.dart';
import 'package:boshliq_app/widgets/small_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class GruppalarPage extends StatefulWidget {
  const GruppalarPage({Key? key}) : super(key: key);

  @override
  State<GruppalarPage> createState() => _GruppalarPageState();
}

class _GruppalarPageState extends State<GruppalarPage> {
  var searchController = TextEditingController();

  void filterSearchResults(String query) {
    List<dynamic> dummySearchList = <dynamic>[];
    dummySearchList.addAll(Get.find<AllDataController>().gruppaList);
    if (query.isNotEmpty) {
      List<dynamic> dummyListData = <dynamic>[];
      dummySearchList.forEach((item) {
        if (item.nomi!.toUpperCase().contains(query.toUpperCase())) {
          dummyListData.add(item);
        }
      });
      setState(() {
        gruppaList.clear();
        gruppaList.addAll(dummyListData);
      });
      return;
    } else {
      setState(() {
        gruppaList.clear();
        gruppaList.addAll(Get.find<AllDataController>().gruppaList);
      });
    }
  }

  List<dynamic> gruppaList = <dynamic>[];


  @override
  void initState(){
    gruppaList.addAll(Get.find<AllDataController>().gruppaList);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: appBarWidget(context,"Gruppalar ro'yhati",AppColors.mainColor),
        body: GetBuilder<AllDataController>(builder: (allDataController){
          return LayoutBuilder(builder: (context2, constraints){
            return Column(
              children: [
                SizedBox(height: Dimensions.height10,),
                AppTextField(
                  textController: searchController,
                  hintText: "Qidirish",
                  icon: Icons.search,
                  onTextChanged: (text){
                    filterSearchResults(text);
                  },
                ),
                SizedBox(height: Dimensions.height10,),
                Expanded(
                  child: GridView.builder(
                  padding: EdgeInsets.all(Dimensions.height20),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount:  constraints.maxWidth ~/ (Dimensions.width20*7) ,
                    crossAxisSpacing: Dimensions.width20,
                    mainAxisSpacing:  Dimensions.width20,
                    childAspectRatio: 1
                  ),
                  shrinkWrap: true,
                  itemCount:gruppaList.length,
                  physics: BouncingScrollPhysics(),
                  itemBuilder: (context,index){
                    return GestureDetector(
                      onTap: (){
                        GruppaModel model = gruppaList[index];
                        Get.toNamed(RouteHelper.getTovarlarPage(model.id!, model.nomi!));
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(Dimensions.radius20),
                          color: AppColors.mainColor,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [

                            SmallText(text: (index+1).toString(),
                            size: Dimensions.font20,
                            color: Colors.black,
                            ),
                            SmallText(text: gruppaList[index].nomi!,
                            size: Dimensions.font20,
                            color: Colors.black,
                            ),
                          ],
                        ),
                      ),
                    );

                  },
              ),
                ),
              ]
            );
          });
        }),
      ),
    );
  }
}
