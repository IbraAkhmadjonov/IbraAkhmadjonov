import 'package:boshliq_app/controllers/all_data_controller.dart';
import 'package:boshliq_app/models/hisobot_turi_model.dart';
import 'package:boshliq_app/pages/home/dialogs/dialog_hisobot_sana.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/widgets/big_text.dart';
import 'package:boshliq_app/widgets/dialog_frame.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DialogHisobotSelect extends StatefulWidget {
  const DialogHisobotSelect({Key? key}) : super(key: key);

  @override
  State<DialogHisobotSelect> createState() => _DialogHisobotSelectState();
}

class _DialogHisobotSelectState extends State<DialogHisobotSelect> {

 late HisobotTuriModel selectedHisobot;

 @override
 void initState() {
   super.initState();
   selectedHisobot = Get.find<AllDataController>().hisobotTurlari[0];
 }

  setSelectedUser(HisobotTuriModel user) {
    setState(() {
      selectedHisobot = user;
    });
  }

  List<Widget> createRadioListUsers(List<HisobotTuriModel> hisobotlar) {
    List<Widget> widgets = [];
    for (HisobotTuriModel hisobot in hisobotlar) {
      widgets.add(
        RadioListTile(
          value: hisobot,
          groupValue: selectedHisobot,
          title: Text(hisobot.nomi!),
          onChanged: (currentUser) {
            // setSelectedUser(currentUser!);
          },
          selected: selectedHisobot == hisobot,
          activeColor: Colors.green,
        ),
      );
    }
    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    return AllDialogSkeleton(
        title: "Hisobotlar",
        icon: Icons.price_change_outlined,
        isExpanded: true,
        child: GetBuilder<AllDataController>(builder: (allDataController) {
            return Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: createRadioListUsers(allDataController.hisobotTurlari),

                    ),
                  ),
                ),
                SizedBox(height: Dimensions.height20,),
                Center(
                  child: GestureDetector(
                    onTap: () {
                      // showCustomSnackbar(selectedHisobot.nomi!);
                      showDialog(
                        context: context,
                        useSafeArea: true,
                        builder: (BuildContext dialogContext) {
                          return DialogHisobotSana(title: selectedHisobot.nomi!,
                            hisobotTuriModel: selectedHisobot,
                            icon: Icons.bar_chart_rounded,);
                        },
                      );
                    },
                    child: Container(
                      width: Dimensions.screenWidth/2,
                      height: Dimensions.screenHeight/17,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(Dimensions.radius15),
                        color: AppColors.mainColor,
                      ),
                      child: Center(
                        child: BigText(
                          text: "Saqlash",
                          size: Dimensions.font20,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: Dimensions.height20),
              ],
            );
          }
        )
    );
  }
}
