import 'package:boshliq_app/base/custom_loader.dart';
import 'package:boshliq_app/base/show_custom_snackbar.dart';
import 'package:boshliq_app/controllers/all_data_controller.dart';
import 'package:boshliq_app/models/agent_model.dart';
import 'package:boshliq_app/models/dokon_model.dart';
import 'package:boshliq_app/pages/home/dialogs/dialog_qidirish.dart';
import 'package:boshliq_app/routes/route_helper.dart';
import 'package:boshliq_app/utils/app_constants.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/utils/type_of_combo_enum.dart';
import 'package:boshliq_app/widgets/app_text_field.dart';
import 'package:boshliq_app/widgets/big_text.dart';
import 'package:boshliq_app/widgets/combobox_field.dart';
import 'package:boshliq_app/widgets/dialog_frame.dart';
import 'package:boshliq_app/widgets/edit_text_field.dart';
import 'package:boshliq_app/widgets/qarzdorlik_field.dart';
import 'package:boshliq_app/widgets/small_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:money_formatter/money_formatter.dart';

class DialogMijozTolov extends StatefulWidget {
  const DialogMijozTolov({Key? key}) : super(key: key);

  @override
  State<DialogMijozTolov> createState() => _DialogMijozTolovState();
}

class _DialogMijozTolovState extends State<DialogMijozTolov> {
  var summaController = TextEditingController();
  var izoxController = TextEditingController();

  late DokonModel _dokonModel =  DokonModel("", "", "", "", "");
  late AgentModel _agentModel =  AgentModel("", "");

  @override
  Widget build(BuildContext context) {
    return AllDialogSkeleton(
        title: "Mijozlardan to'lov qabul qilish",
        isExpanded: false,
        icon: Icons.payments_outlined,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: GetBuilder<AllDataController>(builder: (allDataController) {
            return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: Dimensions.height10/2),
                  ComboBoxField(title: "Do'kon nomi",
                      text: _dokonModel.id!.isEmpty ? "Do'kon nomi tanlang" : _dokonModel.nomi!,
                      icon: Icons.home_work_outlined,
                      typeOfModel: TypeOfComboEnum.dokonlar,
                      onTapFunction: (context2) {
                        showDialog(
                          context: context2,
                          useSafeArea: false,
                          builder: (BuildContext dialogContext) {
                            return DialogQidirish(title: "Do'kon nomi tanlang",
                              typeOfModel: TypeOfComboEnum.dokonlar,
                              icon: Icons.home_work_outlined,);
                          },
                        ).then((value) => {
                          if(value != null){
                            setState((){
                              _dokonModel = value as DokonModel;
                            })
                          }
                        });
                      }
                  ),
                  SizedBox(height: Dimensions.height10,),
                  ComboBoxField(title: "Agent nomi",
                      text: _agentModel.id!.isEmpty ? "Agent nomi tanlang" : _agentModel.nomi!,
                      icon: Icons.person,
                      typeOfModel: TypeOfComboEnum.agentlar,
                      onTapFunction: (context2) {
                        showDialog(
                          context: context2,
                          useSafeArea: false,
                          builder: (BuildContext dialogContext) {
                            return DialogQidirish(title: "Agent nomi tanlang",
                              typeOfModel: TypeOfComboEnum.agentlar,
                              icon: Icons.person,);
                          },
                        ).then((value) => {
                          if(value != null){
                            setState((){
                              _agentModel = value as AgentModel;
                            })
                          }
                        });
                      }
                  ),
                  // Tolov summa
                  SizedBox(height: Dimensions.height10,),
                  EditTextField(title: "To'lov summa",
                    hint: "To'lov summani kiriting",
                    icon: Icons.money,
                    textController: summaController,
                    keyBoardType: TextInputType.number,
                    isNumberFormat: true,
                  ),

                  // Izox
                  SizedBox(height: Dimensions.height10,),
                  EditTextField(title: "Izox",
                    hint: "Izox kiriting",
                    icon: Icons.edit_note,
                    textController: izoxController,
                    keyBoardType: TextInputType.text,
                  ),

                  SizedBox(height: Dimensions.height15*2),
                  // Saqlash
                  allDataController.isLoading ? CustomLoader(sizeCircle: Dimensions.height20*2,):Center(
                    child: GestureDetector(
                      onTap: () {
                        String dok_id = _dokonModel.id!;
                        String agent_id = _agentModel.id!;
                        String summa = summaController.text.trim().replaceAll(" ", "");
                        String izox = izoxController.text.trim();
                        if(dok_id.isEmpty){
                          showCustomSnackbar("Do'kon nomini tanlang",
                              title: "Do'kon nomi");
                        } else if(agent_id.isEmpty){
                          showCustomSnackbar("Agent nomini tanlang",
                              title: "Agent nomi");
                        } else if(summa.isEmpty){
                          showCustomSnackbar("To'lov summasini kiriting", title: "To'lov summa");
                        } else {
                          String sorov_izox = dok_id+"#"+agent_id+"#"+summa+"#"+izox.replaceAll("#", "");

                          allDataController.insertSavol(AppConstants.KEY_MIJOZ_TOLOVI_SAQLASH, sorov_izox).then((response) => {
                            if(response.isSuccess){
                              showCustomSnackbar("To'lov muvaffaqqiyatli saqlandi!",
                                  colorBackground: Colors.green,
                                  title: "Muvaffaqiyatli "+response.message),
                              Navigator.pop(context)
                            } else{
                              showCustomSnackbar(response.message, title: "Xatolik bo'ldi")
                            }
                          });
                        }

                      },
                      child: Container(
                        width: Dimensions.screenWidth/2,
                        height: Dimensions.screenHeight/17,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(Dimensions.radius15),
                          color: AppColors.mainColor,
                        ),
                        child: Center(
                          child: BigText(
                            text: "To'lov qilish",
                            size: Dimensions.font20,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: Dimensions.height15+Dimensions.height10),
                ]
            );
          }),
        )
    );
  }
}
