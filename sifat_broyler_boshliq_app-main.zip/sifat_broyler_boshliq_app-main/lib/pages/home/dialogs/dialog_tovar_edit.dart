import 'package:boshliq_app/base/custom_loader.dart';
import 'package:boshliq_app/base/show_custom_snackbar.dart';
import 'package:boshliq_app/controllers/all_data_controller.dart';
import 'package:boshliq_app/models/tovar_model.dart';
import 'package:boshliq_app/routes/route_helper.dart';
import 'package:boshliq_app/utils/app_constants.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/widgets/app_text_field.dart';
import 'package:boshliq_app/widgets/big_text.dart';
import 'package:boshliq_app/widgets/dialog_frame.dart';
import 'package:boshliq_app/widgets/edit_text_field.dart';
import 'package:boshliq_app/widgets/small_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:money_formatter/money_formatter.dart';

class DialogTovarEdit extends StatefulWidget {

  final TovarModel tovarModel;

  const DialogTovarEdit({Key? key, required this.tovarModel}) : super(key: key);

  @override
  State<DialogTovarEdit> createState() => _DialogTovarEditState();
}

class _DialogTovarEditState extends State<DialogTovarEdit> {
  var kursController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AllDialogSkeleton(
        title: "Tovar narxini o'zgartirish",
        icon: Icons.price_change_outlined,
        isExpanded: false,
        child: GetBuilder<AllDataController>(builder: (allDataController){
          return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: Dimensions.height15),
                Center(
                  child: SmallText(text: widget.tovarModel.nomi!,
                    size: Dimensions.font20,
                    textAlign: TextAlign.center,
                    color: Colors.grey.shade900,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(height: Dimensions.height20,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SmallText(text: "Oldingi narxi: ",
                      size: Dimensions.font16,
                      color: Colors.grey.shade900,),
                    SmallText(text: MoneyFormatter(amount: double.parse(widget.tovarModel.narxi! ?? "0"), settings: MoneyFormatterSettings(thousandSeparator: ' ',)).output.nonSymbol,
                      size: Dimensions.font16,
                      color: Colors.grey.shade900,
                      fontWeight: FontWeight.w700,
                    ),
                  ],
                ),
                SizedBox(height: Dimensions.height20),

                EditTextField(title: "Mahsulot yangi narxi",
                  hint: "Narxini kiriting",
                  icon: Icons.money,
                  textController: kursController,
                  keyBoardType: TextInputType.number,
                  isNumberFormat: true,
                ),
                SizedBox(height: Dimensions.height15*2,),
                allDataController.isLoading ? CustomLoader(sizeCircle: Dimensions.height20*2,):Center(
                  child: GestureDetector(
                    onTap: () {
                      String yangi_kurs = kursController.text.trim().replaceAll(" ", "");
                      if(yangi_kurs.isEmpty){
                        showCustomSnackbar("Iltimos yangi narxini kiriting!",
                            title: "Narx");
                      } else {
                        String sorov_izox = "${widget.tovarModel.id}#$yangi_kurs#${widget.tovarModel.narxi}";

                        allDataController.insertSavol(AppConstants.KEY_TOVAR_OZGARTIRISH, sorov_izox).then((response) => {
                          if(response.isSuccess){
                            showCustomSnackbar("Narx muvaffaqqiyatli o'zgartirildi!",
                                colorBackground: Colors.green,
                                title: "Muvaffaqiyatli "+response.message),
                            Navigator.pop(context)
                          } else{
                            showCustomSnackbar(response.message, title: "Xatolik bo'ldi")
                          }
                        });
                      }

                    },
                    child: Container(
                      width: Dimensions.screenWidth/2,
                      height: Dimensions.screenHeight/17,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(Dimensions.radius15),
                        color: AppColors.mainColor,
                      ),
                      child: Center(
                        child: BigText(
                          text: "Saqlash",
                          size: Dimensions.font20,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: Dimensions.height15*2),
              ]
          );
        })
    );
  }
}
