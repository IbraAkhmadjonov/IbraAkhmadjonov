import 'package:boshliq_app/controllers/all_data_controller.dart';
import 'package:boshliq_app/models/dokon_model.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/utils/type_of_combo_enum.dart';
import 'package:boshliq_app/widgets/app_text_field.dart';
import 'package:boshliq_app/widgets/dialog_frame.dart';
import 'package:boshliq_app/widgets/small_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DialogQidirish extends StatefulWidget {
  String title;
  IconData icon;
  TypeOfComboEnum typeOfModel;

  DialogQidirish({
    Key? key,
    required this.title,
    required this.typeOfModel,
    required this.icon}) : super(key: key);

  @override
  State<DialogQidirish> createState() => _DialogQidirishState();
}

class _DialogQidirishState extends State<DialogQidirish> {
    var searchController = TextEditingController();

  void filterSearchResults(String query) {
    List<dynamic> dummySearchList = <dynamic>[];
    dummySearchList.addAll(dokonAllList);
    if (query.isNotEmpty) {
      List<dynamic> dummyListData = <dynamic>[];
      dummySearchList.forEach((item) {
        if (item.nomi!.toUpperCase().contains(query.toUpperCase())) {
          dummyListData.add(item);
        }
      });
      setState(() {
        dokonList.clear();
        dokonList.addAll(dummyListData);
      });
      return;
    } else {
      setState(() {
        dokonList.clear();
        dokonList.addAll(dokonAllList);
      });
    }
  }

  List<dynamic> dokonAllList = [];
  List<dynamic> dokonList = <dynamic>[];

  @override
  void initState(){
    if(widget.typeOfModel == TypeOfComboEnum.dokonlar) {
      dokonAllList.addAll(Get
          .find<AllDataController>()
          .dokonlarList);
    } else if(widget.typeOfModel == TypeOfComboEnum.yuk_beruvchilar) {
      dokonAllList.addAll(Get
          .find<AllDataController>()
          .yukBeruvchilarList);
    } else if(widget.typeOfModel == TypeOfComboEnum.agentlar){
      dokonAllList.addAll(Get
          .find<AllDataController>()
          .agentlarList);
    } else if(widget.typeOfModel == TypeOfComboEnum.tovarlar){
      dokonAllList.addAll(Get
          .find<AllDataController>()
          .tovarlarList);
    } else if(widget.typeOfModel == TypeOfComboEnum.mahsulot_turlari){
      dokonAllList.addAll(Get
          .find<AllDataController>()
          .gruppaList);
    }
    dokonList.addAll(dokonAllList);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    return AllDialogSkeleton(
        title: widget.title,
        icon: widget.icon,
        isExpanded: true,
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AppTextField(
                  textController: searchController,
                  hintText: "Qidirish",
                  icon: Icons.search,
                  onTextChanged: (text){
                    filterSearchResults(text);
                  },
              ),
              SizedBox(height: Dimensions.height10,),
              Expanded(
                child: ListView.builder(
                    itemCount: dokonList.length,
                    shrinkWrap: true,
                    padding: EdgeInsets.fromLTRB(Dimensions.width10, Dimensions.height20/5, Dimensions.width10, Dimensions.height20/5),
                    itemBuilder: (context2, index){
                      return GestureDetector(
                        onTap: (){
                          Navigator.pop(context,dokonList[index]);
                        },
                        child: Container(
                          color: Colors.white,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: Dimensions.height10,),
                              SmallText(text: dokonList[index].nomi!,
                                textAlign: TextAlign.left,
                                size: Dimensions.font16,
                                color: Colors.black,
                                fontWeight: FontWeight.w600,),
                              SizedBox(height: Dimensions.height10,),
                              Divider(height: Dimensions.height10/5, color: AppColors.mainColor,)
                            ],
                          ),
                        ),
                      );
                    }
                ),
              )
            ]
        )
    );
  }
}
