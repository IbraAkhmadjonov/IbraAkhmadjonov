import 'package:boshliq_app/base/dialog_loading.dart';
import 'package:boshliq_app/base/show_custom_snackbar.dart';
import 'package:boshliq_app/controllers/all_data_controller.dart';
import 'package:boshliq_app/models/agent_model.dart';
import 'package:boshliq_app/models/dokon_model.dart';
import 'package:boshliq_app/models/gruppa_model.dart';
import 'package:boshliq_app/models/hisobot_turi_model.dart';
import 'package:boshliq_app/models/tovar_model.dart';
import 'package:boshliq_app/pages/home/dialogs/dialog_qidirish.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/utils/type_of_combo_enum.dart';
import 'package:boshliq_app/widgets/app_text_field.dart';
import 'package:boshliq_app/widgets/big_text.dart';
import 'package:boshliq_app/widgets/combobox_field.dart';
import 'package:boshliq_app/widgets/dialog_frame.dart';
import 'package:boshliq_app/widgets/small_text.dart';
import 'package:boshliq_app/widgets/web_view_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

class DialogHisobotSana extends StatefulWidget {
  String title;
  IconData icon;
  HisobotTuriModel hisobotTuriModel;

  DialogHisobotSana({
    Key? key,
    required this.title,
    required this.hisobotTuriModel,
    required this.icon}) : super(key: key);

  @override
  State<DialogHisobotSana> createState() => _DialogHisobotSanaState();
}

class _DialogHisobotSanaState extends State<DialogHisobotSana> {

  late DokonModel _dokonModel =  DokonModel("", "", "", "", "");
  late DokonModel _yukBeruvchiModel =  DokonModel("", "", "", "", "");
  late TovarModel _tovarModel =  TovarModel("", "", "", "", "");
  late AgentModel _agentModel =  AgentModel("", "");
  late GruppaModel _gruppaModel =  GruppaModel("", "");

  DateTime selectedDate = DateTime.now();
  DateTime selectedDate2 = DateTime.now();

  Future<void> _selectDate(BuildContext context, int turi) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: turi == 1 ? selectedDate : selectedDate2,
        firstDate: DateTime(2015, 8),
        lastDate: DateTime(2101));
    if (picked != null) {
      setState(() {
        if(turi == 1){
          selectedDate = picked;
        } else {
          selectedDate2 = picked;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    return AllDialogSkeleton(
        title: widget.title,
        icon: widget.icon,
        isExpanded: false,
        child: GetBuilder<AllDataController>(builder: (allDataController){
          return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                Row(
                  children: [
                    Expanded(
                      child: ComboBoxField(title: "Sana 1",
                          text: DateFormat('dd.MM.yyyy').format(selectedDate),
                          icon: Icons.date_range,
                          typeOfModel: TypeOfComboEnum.sana,
                          onTapFunction: (context2) {
                            _selectDate(context,1);
                          }
                      ),
                    ),
                    SizedBox(width: Dimensions.width10,),
                    widget.hisobotTuriModel.sana_2?
                    Expanded(
                      child: ComboBoxField(title: "Sana 2",
                          text: DateFormat('dd.MM.yyyy').format(selectedDate2),
                          icon: Icons.date_range,
                          typeOfModel: TypeOfComboEnum.sana,
                          onTapFunction: (context2) {
                            _selectDate(context,2);
                          }
                      ),
                    ) : Container()
                  ],
                ),


                widget.hisobotTuriModel.yuk_beruvchi?
                ComboBoxField(title: "Yuk beruvchi nomi",
                    text: _yukBeruvchiModel.id!.isEmpty ? "Yuk beruvchi tanlang" : _yukBeruvchiModel.nomi!,
                    icon: Icons.home_work_outlined,
                    typeOfModel: TypeOfComboEnum.yuk_beruvchilar,
                    onTapFunction: (context2) {
                      showDialog(
                        context: context2,
                        useSafeArea: false,
                        builder: (BuildContext dialogContext) {
                          return DialogQidirish(title: "Yuk beruvchi tanlang",
                            typeOfModel: TypeOfComboEnum.yuk_beruvchilar,
                            icon: Icons.home_work_outlined,);
                        },
                      ).then((value) => {
                        if(value != null){
                          setState((){
                            _yukBeruvchiModel = value as DokonModel;
                          })
                        }
                      });
                    }
                ):Container(),

                widget.hisobotTuriModel.mijoz ?
                ComboBoxField(title: "Do'kon nomi",
                    text: _dokonModel.id!.isEmpty ? "Do'kon nomi tanlang" : _dokonModel.nomi!,
                    icon: Icons.home_work_outlined,
                    typeOfModel: TypeOfComboEnum.dokonlar,
                    onTapFunction: (context2) {
                      showDialog(
                        context: context2,
                        useSafeArea: false,
                        builder: (BuildContext dialogContext) {
                          return DialogQidirish(title: "Do'kon nomi tanlang",
                            typeOfModel: TypeOfComboEnum.dokonlar,
                            icon: Icons.home_work_outlined,);
                        },
                      ).then((value) => {
                        if(value != null){
                          setState((){
                            _dokonModel = value as DokonModel;
                          })
                        }
                      });
                    }
                ) : Container(),

                widget.hisobotTuriModel.agent ?
                ComboBoxField(title: "Agent FIO",
                    text: _agentModel.id!.isEmpty ? "Agent FIO tanlang" : _agentModel.nomi!,
                    icon: Icons.person_outlined,
                    typeOfModel: TypeOfComboEnum.agentlar,
                    onTapFunction: (context2) {
                      showDialog(
                        context: context2,
                        useSafeArea: false,
                        builder: (BuildContext dialogContext) {
                          return DialogQidirish(title: "Agent FIO tanlang",
                            typeOfModel: TypeOfComboEnum.agentlar,
                            icon: Icons.person_outlined,);
                        },
                      ).then((value) => {
                        if(value != null){
                          setState((){
                            _agentModel = value as AgentModel;
                          })
                        }
                      });
                    }
                ):Container(),
                //
                // widget.hisobotTuriModel.ombor ?
                //   ComboBoxField(title: "Ombor nomi",
                //     text: _dokonModel.id!.isEmpty ? "Ombor nomi tanlang" : _dokonModel.nomi!,
                //     icon: Icons.broadcast_on_home_outlined,
                //     typeOfModel: TypeOfComboEnum.omborlar,
                //     onTapFunction: (context2) {
                //       showDialog(
                //         context: context2,
                //         useSafeArea: false,
                //         builder: (BuildContext dialogContext) {
                //           return DialogQidirish(title: "Ombor nomi tanlang",
                //             typeOfModel: TypeOfComboEnum.omborlar,
                //             icon: Icons.broadcast_on_home_outlined,);
                //         },
                //       ).then((value) => {
                //         if(value != null){
                //           setState((){
                //             _dokonModel = value as DokonModel;
                //           })
                //         }
                //       });
                //     }
                // ):Container(),

                widget.hisobotTuriModel.mahsulot_turi ?
                ComboBoxField(title: "Mahsulot turi",
                    text: _gruppaModel.id!.isEmpty ? "Mahsulot turi tanlang" : _gruppaModel.nomi!,
                    icon: Icons.merge_type,
                    typeOfModel: TypeOfComboEnum.mahsulot_turlari,
                    onTapFunction: (context2) {
                      showDialog(
                        context: context2,
                        useSafeArea: false,
                        builder: (BuildContext dialogContext) {
                          return DialogQidirish(title: "Mahsulot turi tanlang",
                            typeOfModel: TypeOfComboEnum.mahsulot_turlari,
                            icon: Icons.merge_type,);
                        },
                      ).then((value) => {
                        if(value != null){
                          setState((){
                            _gruppaModel = value as GruppaModel;
                          })
                        }
                      });
                    }
                ):Container(),

                widget.hisobotTuriModel.mahsulot ?
                ComboBoxField(title: "Mahsulot nomi",
                    text: _tovarModel.id!.isEmpty ? "Mahsulot nomi tanlang" : _tovarModel.nomi!,
                    icon: Icons.space_dashboard_outlined,
                    typeOfModel: TypeOfComboEnum.tovarlar,
                    onTapFunction: (context2) {
                      showDialog(
                        context: context2,
                        useSafeArea: false,
                        builder: (BuildContext dialogContext) {
                          return DialogQidirish(title: "Mahsulot nomi tanlang",
                            typeOfModel: TypeOfComboEnum.tovarlar,
                            icon: Icons.space_dashboard_outlined,);
                        },
                      ).then((value) => {
                        if(value != null){
                          setState((){
                            _tovarModel = value as TovarModel;
                          })
                        }
                      });
                    }
                ):Container(),

                SizedBox(height: Dimensions.height20,),

                Center(
                  child: GestureDetector(
                    onTap: () {
                      if(widget.hisobotTuriModel.is_required_mijoz){
                        if(_dokonModel.id!.isEmpty){
                          showCustomSnackbar("Iltimos do'kon tanlang!",title: "Do'kon");
                          return;
                        }
                      }
                      if(widget.hisobotTuriModel.is_required_agent){
                        if(_agentModel.id!.isEmpty){
                          showCustomSnackbar("Iltimos agent tanlang!",title: "Agent");
                          return;
                        }
                      }
                      if(widget.hisobotTuriModel.is_required_yuk_beruvchi){
                        if(_yukBeruvchiModel.id!.isEmpty){
                          showCustomSnackbar("Iltimos yuk beruvchi tanlang!",title: "Yuk beruvchi");
                          return;
                        }
                      }

                      String dok_id = _dokonModel.id!;
                      String yuk_id = _yukBeruvchiModel.id!;
                      String agent_id = _agentModel.id!;
                      String mahsulot_id = _tovarModel.id!;
                      String gruppa_id = _gruppaModel.id!;
                      String sana_1 = DateFormat("dd.MM.yyyy").format(selectedDate);
                      String sana_2 = DateFormat("dd.MM.yyyy").format(selectedDate2);

                      String sorov_izox = "$sana_1#$sana_2#$yuk_id#$dok_id#$agent_id#$gruppa_id#$mahsulot_id#";

                      showDialog(context: context,
                          barrierDismissible: false,
                          builder: (context){
                        return DialogLoading();
                      });

                      allDataController.getJavobFromSavol(widget.hisobotTuriModel.id!,sorov_izox).then((response) => {
                        if(response.isSuccess){
                          Get.back(),
                          Get.to(WebViewPage(
                          hisobotTuriModel: widget.hisobotTuriModel,
                          sorovIzox: sorov_izox,
                          htmlString: response.message,
                          title: widget.hisobotTuriModel.nomi!))
                      } else{
                          Get.back(),
                          showCustomSnackbar(response.message, title: "Xatolik bo'ldi")
                        }
                      });

                    },
                    child: Container(
                      width: Dimensions.screenWidth/2,
                      height: Dimensions.screenHeight/17,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(Dimensions.radius15),
                        color: AppColors.mainColor,
                      ),
                      child: Center(
                        child: BigText(
                          text: "Kegingi",
                          size: Dimensions.font20,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: Dimensions.height10,),
              ]
          );
        })
    );
  }
}
