import 'package:boshliq_app/base/dialog_loading.dart';
import 'package:boshliq_app/controllers/all_data_controller.dart';
import 'package:boshliq_app/pages/home/dialogs/dialog_hisobot_select.dart';
import 'package:boshliq_app/pages/home/dialogs/dialog_kurs_edit.dart';
import 'package:boshliq_app/pages/home/dialogs/dialog_mijoz_tolov.dart';
import 'package:boshliq_app/pages/home/dialogs/dialog_yuk_tolov.dart';
import 'package:boshliq_app/routes/route_helper.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/widgets/app_text_field.dart';
import 'package:boshliq_app/widgets/dialog_frame.dart';
import 'package:boshliq_app/widgets/home_menu_button.dart';
import 'package:boshliq_app/widgets/small_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:boshliq_app/helper/dependencies.dart' as dep;
import 'package:shared_preferences/shared_preferences.dart';
class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {


  Future<void> _loadResource() async{

    await Get.find<AllDataController>().getYukBeruvchilar();
    await Get.find<AllDataController>().getDokonlar();
    await Get.find<AllDataController>().getAgentlar();
    await Get.find<AllDataController>().getTovarlar();
    await Get.find<AllDataController>().getGruppalar();
    // await Get.find<AllDataController>().getDollarKursi();
  }

  @override
  void initState() {
    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    _loadResource();
    return RefreshIndicator(
      onRefresh: _loadResource,
      child: Scaffold(
        // resizeToAvoidBottomInset: false,
        body: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          child: Container(
            color: Colors.white,
            width: double.infinity,
            height: MediaQuery.of(context).size.height,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: Dimensions.height20*6,
                  child: Image.asset("assets/images/logo.jpg"),
                ),
                SizedBox(height: Dimensions.height15*2,),
                Container(
                  height: Dimensions.heightMainBord,
                  margin: EdgeInsets.all(Dimensions.width20),
                  decoration: BoxDecoration(
                      color: AppColors.mainColor,
                    borderRadius: BorderRadius.circular(Dimensions.radius20)
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [

                          // Tolov qilish
                          HomeMenuButton(icon: Icons.space_dashboard_outlined,
                              text: "Tovarlar o'zgartirish",
                              onTapFunction: (){
                                Get.toNamed(RouteHelper.getGruppaPage());
                              }),

                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          // Yuk beruvchi tolov
                          HomeMenuButton(icon: Icons.payments_outlined,
                              text: "Yuk beruvchiga to'lov",
                              onTapFunction: (){
                                showDialog(context: context,
                                    barrierDismissible: false,
                                    builder: (context){
                                  return DialogYukTolov();
                                });
                              }),

                          // Mijoz tolov
                          HomeMenuButton(icon: Icons.paypal_rounded,
                              text: "Mijoz to'lovlari",
                              onTapFunction: (){
                                showDialog(context: context,
                                    barrierDismissible: false,
                                    builder: (context){
                                  return DialogMijozTolov();
                                });
                              }),

                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          // Xisobot
                          HomeMenuButton(icon: Icons.bar_chart_rounded,
                              text: "Hisobotlar",
                              onTapFunction: (){
                                showDialog(context: context, builder: (context){
                                  return DialogHisobotSelect();
                                });
                              }),

                          // Sozlama
                          HomeMenuButton(icon: Icons.settings,
                              text: "Sozlama",
                              onTapFunction: (){
                                Get.toNamed(RouteHelper.getSozlamaPage());
                              }),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
