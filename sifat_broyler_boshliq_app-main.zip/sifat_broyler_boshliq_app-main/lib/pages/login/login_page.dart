import 'package:boshliq_app/base/custom_loader.dart';
import 'package:boshliq_app/base/show_custom_snackbar.dart';
import 'package:boshliq_app/controllers/auth_controller.dart';
import 'package:boshliq_app/routes/route_helper.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/widgets/app_text_field.dart';
import 'package:boshliq_app/widgets/big_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    var phoneController = TextEditingController();
    var passwordController = TextEditingController();

    void _login(AuthController authController){
      String phone = phoneController.text.trim();
      String password = passwordController.text.trim();

      if(phone.isEmpty){
        showCustomSnackbar("Telefon raqamingizni kiriting", title: "Telefon raqam");
      } else if(password.isEmpty){
        showCustomSnackbar("Parolingizni kiriting", title: "Parol");
      }else if(password.length<4){
        showCustomSnackbar("Parol 4 ta belgidan kam bo'lmasligi kerak!", title: "Parol");
      }else{
        authController.login(phone,password).then((status){
          if(status.isSuccess){
            Get.offNamed(RouteHelper.getInitial());
          } else {
            showCustomSnackbar(status.message);
          }
        });
      }

    }
    return Scaffold(
      backgroundColor: Colors.white,
      body: GetBuilder<AuthController>(builder: (authController) {
        return Container(
          color: Colors.white,
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: Dimensions.height20*6,
                child: Image.asset("assets/images/logo.jpg"),
              ),
              SizedBox(height: Dimensions.height15*2,),
              AppTextField(
                textController: phoneController,
                hintText: "Telefon raqam",
                icon: Icons.phone,
                keyBoardType: TextInputType.phone,
                maxLength: 13,
                onTextChanged: (text){

                },
              ),
              SizedBox(height: Dimensions.height15*2,),
              AppTextField(
                textController: passwordController,
                hintText: "Parol",
                icon: Icons.password_sharp,
                isObscure: true,
                onTextChanged: (text){

                },
              ),
              SizedBox(height: Dimensions.height15*2,),
              authController.isLoading ? CustomLoader(sizeCircle: Dimensions.height20*3,): GestureDetector(
                onTap: (){
                  _login(authController);
                },
                child: Container(
                  width: Dimensions.screenWidth/2,
                  height: Dimensions.screenHeight/15,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(Dimensions.radius15),
                    color: AppColors.mainColor,
                  ),
                  child: Center(
                    child: BigText(
                      text: "Kirish",
                      size: Dimensions.font20+Dimensions.font20/4,
                      color: Colors.white,
                    ),
                  ),
                ),
              )
            ],
          ),
        );
      }),
    );
  }
}
