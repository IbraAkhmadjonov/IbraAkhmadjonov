import 'package:boshliq_app/base/custom_loader.dart';
import 'package:boshliq_app/controllers/auth_controller.dart';
import 'package:boshliq_app/routes/route_helper.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/widgets/icon_and_text_field.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SozlamaPage extends StatefulWidget {
  const SozlamaPage({Key? key}) : super(key: key);

  @override
  State<SozlamaPage> createState() => _SozlamaPageState();
}

class _SozlamaPageState extends State<SozlamaPage> {

  @override
  Widget build(BuildContext context) {

    Get.find<AuthController>().getUserInfo();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: AppColors.mainColor,
        title: Text("Shaxsiy kabinet"),
      ),
      body: GetBuilder<AuthController>(builder: (userController){
        return userController.isLoading ? CustomLoader(sizeCircle: Dimensions.height20*3,):
        Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: Dimensions.height20*2,),
            Center(
              child: CircleAvatar(
                backgroundColor: AppColors.mainColor,
                radius: Dimensions.height20*3,
                child: SizedBox(
                    width: Dimensions.height15*4,
                    height: Dimensions.height15*4,
                    child: Image.asset("assets/images/user_logo_oq.png",)),
              ),
            ),
            SizedBox(height: Dimensions.height20*2,),
            IconAndTextField(
              title: "FIO",
              text: userController.userModel.fio!,
              icon: Icons.person,
              onTapFunction: (){

              },
            ),
            SizedBox(height: Dimensions.height15,),
            IconAndTextField(
              title: "Telefon",
              text: userController.userModel.telefon!,
              icon: Icons.phone,
              onTapFunction: (){

              },
            ),
            SizedBox(height: Dimensions.height15,),
            IconAndTextField(
              title: "Log out",
              text: "Dasturdan chiqish",
              icon: Icons.logout,
              onTapFunction: (context2){
                showDialog(context: context2, builder: (contextB){
                  return AlertDialog(
                    title: Text("Log out"),
                    content: Text("Dasturdan chiqmoqchimisiz?"),
                    actions: [
                      TextButton(onPressed: (){
                        Navigator.pop(context);
                      }, child: Text("Yo'q")),
                      TextButton(onPressed: (){
                        Get.find<AuthController>().clearSharedData();
                        Navigator.pop(context);
                        Get.offNamed(RouteHelper.getSplashPage());
                      }, child: Text("Ha")),
                    ],
                  );
                });
              },
            )
          ],
        );
      })
    );
  }
}
