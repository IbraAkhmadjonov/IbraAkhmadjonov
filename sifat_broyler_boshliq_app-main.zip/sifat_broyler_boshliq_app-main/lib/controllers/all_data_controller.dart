import 'dart:convert';

import 'package:boshliq_app/data/repository/all_data_repo.dart';
import 'package:boshliq_app/models/agent_model.dart';
import 'package:boshliq_app/models/dokon_model.dart';
import 'package:boshliq_app/models/gruppa_model.dart';
import 'package:boshliq_app/models/hisobot_turi_model.dart';
import 'package:boshliq_app/models/response_model.dart';
import 'package:boshliq_app/models/tovar_model.dart';
import 'package:boshliq_app/models/user_model.dart';
import 'package:boshliq_app/utils/app_constants.dart';
import 'package:get/get.dart';

class AllDataController extends GetxController {
  final AllDataRepo allDataRepo;

  AllDataController({required this.allDataRepo});

  bool ended = true;
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  List<DokonModel> _dokonlarList = [];
  List<DokonModel> get dokonlarList => _dokonlarList;

  List<DokonModel> _yukBeruvchilarList = [];
  List<DokonModel> get yukBeruvchilarList => _yukBeruvchilarList;

  List<AgentModel> _agentlarList = [];
  List<AgentModel> get agentlarList => _agentlarList;

  List<TovarModel> _tovarlarList = [];
  List<TovarModel> get tovarlarList => _tovarlarList;

  List<GruppaModel> _gruppaList = [];
  List<GruppaModel> get gruppaList => _gruppaList;

  String _dollar_kursi = "0";
  String get dollar_kursi => _dollar_kursi;

  List<HisobotTuriModel> hisobotTurlari = [
    HisobotTuriModel("21","Савдо руйхати",true,true,true,false,true,false,true,true,),
    HisobotTuriModel("22", "Кирим руйхати", true, true, false, true, false, true, true, true),
    HisobotTuriModel("23", "Гушт колдиги", true, false, false, false, false, true, true, true),
    HisobotTuriModel("24", "Гушт айланмаси", true, true, false, false, false, true, true, true),
    HisobotTuriModel("25", "Мижозлар бўйича савдо айланмаси", true, true, true, false, false, false, false, false),
    HisobotTuriModel("26", "Мижозлар колдиғи", true, false, true, false, false, false, false, false),
    HisobotTuriModel("27", "Мижозлар билан АКТ-СВЕРКА", true, true, true, false, false, false, false, false)..is_required_mijoz = true,
    HisobotTuriModel("28", "Мижоз карточкаси", true, true, true, false, false, false, false, false)..is_required_mijoz = true,
    HisobotTuriModel("29", "Юк берувчилар бўйича савдо айланмаси", true, true, false, true, false, false, false, false),
    HisobotTuriModel("30", "Юк берувчилар колдиғи", true, false, false, true, false, false, false, false),
    HisobotTuriModel("31", "Юк берувчилар билан АКТ-СВЕРКА", true, true, false, true, false, false, false, false)..is_required_yuk_beruvchi = true,
    HisobotTuriModel("32", "Харажатлар", true, true, false, false, false, false, false, false),
    HisobotTuriModel("33", "Касса (Кирим-Чиқим)", true, true, false, false, false, false, false, false),
    HisobotTuriModel("34", "Ходимлар айланма хисоботи", true, true, false, false, true, false, false, false),
    HisobotTuriModel("35", "Ходимлар билан АКТ-СВЕРКА", true, true, false, false, true, false, false, false)..is_required_agent = true,
    HisobotTuriModel("36", "Ходимлар колдиғи", true, true, false, false, true, false, false, false),
    HisobotTuriModel("37", "Фойда", true, true, false, false, false, false, false, false),

  ];

  Future<void> getDokonlar() async {
    _dokonlarList = [];
    Response response = await allDataRepo.getDokonlar();
    if(response.statusCode == 200){
      List<dynamic> royh = jsonDecode(response.body);
      royh.forEach((value) {
        _dokonlarList.add(DokonModel.fromJson(value));
      });
    }
  }

  Future<void> getYukBeruvchilar() async {
    _yukBeruvchilarList = [];
    Response response = await allDataRepo.getYukBeruvchilar();
    if(response.statusCode == 200){
      List<dynamic> royh = jsonDecode(response.body);
      royh.forEach((value) {
        _yukBeruvchilarList.add(DokonModel.fromJson(value));
      });
    }
  }

  Future<void> getAgentlar() async {
    _agentlarList = [];
    Response response = await allDataRepo.getAgentlar();
    if(response.statusCode == 200){
      List<dynamic> royh = jsonDecode(response.body);
      royh.forEach((value) {
        _agentlarList.add(AgentModel.fromJson(value));
      });
    }
  }

  Future<void> getTovarlar() async {
    _tovarlarList = [];
    Response response = await allDataRepo.getTovarlar();
    if(response.statusCode == 200){
      List<dynamic> royh = jsonDecode(response.body);
      royh.forEach((value) {
        _tovarlarList.add(TovarModel.fromJson(value));
      });
    }
  }

  Future<void> getGruppalar() async {
    _gruppaList = [];
    Response response = await allDataRepo.getGruppalar();
    if(response.statusCode == 200){
      List<dynamic> royh = jsonDecode(response.body);
      royh.forEach((value) {
        _gruppaList.add(GruppaModel.fromJson(value));
      });
    }
  }

  Future<void> getDollarKursi() async {
    _dollar_kursi = "0";
    Response response = await allDataRepo.getDollarKursi();
    if(response.statusCode == 200){
      _dollar_kursi = response.body.toString();
    }
  }


  Future<ResponseModel> insertSavol(String sorovTuri, String sorovIzox) async {
    _isLoading = true;
    update();

    Response response = await allDataRepo.insertSavol(sorovTuri, sorovIzox);
    late ResponseModel responseModel;
    if(response.statusCode == 200){
      var model = UserModel.fromJson(jsonDecode(response.body));
      if(model.success == true){
        responseModel = ResponseModel(true, model.response!);
      } else {
        responseModel = ResponseModel(false, model.message!);
      }
    } else {
      responseModel = ResponseModel(false, response.statusText!);
    }
    _isLoading=false;
    update();
    return responseModel;
  }

  Future<ResponseModel> getJavobFromSavol(String sorov_turi, String izox) async {
     _isLoading = true;
     ended = true;
     update();
     ResponseModel responseModel = ResponseModel(false, "Xatolik bo'ldi");
     Response response = await allDataRepo.insertSavol(sorov_turi, izox);
     if(response.statusCode == 200){
       var model = UserModel.fromJson(jsonDecode(response.body));
       if(model.success == true){
         while(ended) {
           Response response = await allDataRepo.getJavob(model.response!);
           if (response.statusCode == 200 &&
               response.body != null &&
               response.body.toString() != "null" &&
               response.body.toString() != "" &&
               response.body.toString() != "no" &&
               response.body.toString() != "no_c") {
             ended = false;
             var model1 = UserModel.fromJson(jsonDecode(response.body));
             if(model1.success == true){
               responseModel = ResponseModel(true, model1.response!);
             } else {
               responseModel = ResponseModel(false, model1.message!);
             }
           } else {
             Future.delayed(const Duration(seconds: 1));
           }
         }
       } else {
         responseModel = ResponseModel(false, model.message!);
       }
     } else {
       responseModel = ResponseModel(false, response.statusText!);
     }
    _isLoading=false;
    update();
     return responseModel;
  }

}