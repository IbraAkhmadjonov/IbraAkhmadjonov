import 'dart:convert';

import 'package:boshliq_app/data/repository/auth_repo.dart';
import 'package:boshliq_app/models/response_model.dart';
import 'package:boshliq_app/models/user_model.dart';
import 'package:get/get.dart';

class AuthController extends GetxController implements GetxService{

  final AuthRepo authRepo;

  AuthController({required this.authRepo});

  bool _isLoading = false;

  bool get isLoading => _isLoading;

  late UserModel _userModel;
  UserModel get userModel => _userModel;

  Future<ResponseModel> login(String phone, String password) async {
    _isLoading = true;
    update();

    Response response = await authRepo.login(phone, password);
    late ResponseModel responseModel;
    if(response.statusCode == 200){
      var model = UserModel.fromJson(jsonDecode(response.body));
      if(model.success == true){
        authRepo.saveUserData(model);
        responseModel = ResponseModel(true, "");
      } else {
        responseModel = ResponseModel(false, model.message!);
      }
    } else {
      responseModel = ResponseModel(false, response.statusText!);
    }
    _isLoading=false;
    update();
    return responseModel;
  }


  bool userLoggedIn(){
    return authRepo.userLoggedIn();
  }

  bool clearSharedData(){
    return authRepo.clearSharedData();
  }


  Future<ResponseModel> getUserInfo() async {
    _isLoading = true;
    update();
    Response response = await authRepo.getUserInfo();
    late ResponseModel responseModel;
    if(response.statusCode == 200){
      _userModel = UserModel.fromJson(jsonDecode(response.body));
      responseModel = ResponseModel(true, "Success");
    }else{
      responseModel = ResponseModel(false, response.statusText!);
    }
    _isLoading = false;
    update();
    return responseModel;
  }

}