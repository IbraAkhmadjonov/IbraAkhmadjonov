import 'package:boshliq_app/data/api/api_client.dart';
import 'package:boshliq_app/models/user_model.dart';
import 'package:boshliq_app/utils/app_constants.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthRepo{
  final ApiClient apiClient;
  final SharedPreferences sharedPreferences;
  
  AuthRepo({required this.apiClient, required this.sharedPreferences});
  
  Future<Response> login(String phone, String password) async {
    return await apiClient.postData(AppConstants.URL_LOGIN, {"telefon":phone, "parol":password});
  }

  Future<bool> saveUserData(UserModel userModel) async {
    apiClient.token = userModel.Id!;

     await sharedPreferences.setString(AppConstants.USER_ID, userModel.Id!);
     await sharedPreferences.setString(AppConstants.USER_FIO, userModel.fio!);
     await sharedPreferences.setString(AppConstants.USER_PHONE, userModel.telefon!);
    return await sharedPreferences.setString(AppConstants.USER_PASSWORD, userModel.parol!);
  }

  bool userLoggedIn(){
    return sharedPreferences.containsKey(AppConstants.USER_ID);
  }

  bool clearSharedData(){
    sharedPreferences.remove(AppConstants.USER_ID);
    sharedPreferences.remove(AppConstants.USER_FIO);
    sharedPreferences.remove(AppConstants.USER_PASSWORD);
    sharedPreferences.remove(AppConstants.USER_PHONE);
    apiClient.token = '';
    apiClient.uodateHeader("");
    return true;
  }


  Future<Response> getUserInfo() async{

    String telefon = sharedPreferences.getString(AppConstants.USER_PHONE) ?? "";
    String parol = sharedPreferences.getString(AppConstants.USER_PASSWORD) ?? "";

    return await apiClient.postData(AppConstants.URL_LOGIN,
        {"telefon":telefon, "parol":parol}
    );
  }

}