import 'package:boshliq_app/data/api/api_client.dart';
import 'package:boshliq_app/utils/app_constants.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AllDataRepo extends GetxService{
  final ApiClient apiClient;
  final SharedPreferences sharedPreferences;

  AllDataRepo({required this.apiClient, required this.sharedPreferences});
  
  Future<Response> getDokonlar() async {
    return await apiClient.getData(AppConstants.URL_GET_DOKONLAR);
  }

  Future<Response> getYukBeruvchilar() async {
    return await apiClient.getData(AppConstants.URL_GET_YUK_BERUVCHILAR);
  }

  Future<Response> getAgentlar() async {
    return await apiClient.getData(AppConstants.URL_GET_AGENTLAR);
  }

  Future<Response> getTovarlar() async {
    return await apiClient.getData(AppConstants.URL_GET_TOVARLAR);
  }

  Future<Response> getGruppalar() async {
    return await apiClient.getData(AppConstants.URL_GET_GRUPPALAR);
  }

  Future<Response> getDollarKursi() async {
    return await apiClient.getData(AppConstants.URL_GET_DOLLAR_KURSI);
  }


  Future<Response> insertSavol(String sorovTuri, String sorovIzox) async {
    String user_id = sharedPreferences.getString(AppConstants.USER_ID) ?? "";
    return await apiClient.postData(AppConstants.URL_INSERT_SAVOL, {"user_id":user_id, "sorov_turi": sorovTuri, "sorov_izox":sorovIzox});
  }

  Future<Response> getJavob(String sorovIzox) async {
    String user_id = sharedPreferences.getString(AppConstants.USER_ID) ?? "";
    return await apiClient.postData(AppConstants.URL_GET_JAVOB, {"user_id":user_id, "sorov_id": sorovIzox});
  }

  
}