class DokonModel {
  String? id;
  String? nomi;
  String? regId;
  String? regNomi;
  String? qarzi;


  DokonModel(this.id, this.nomi, this.regId, this.regNomi, this.qarzi);

  Map<String, dynamic> toJson(){
    return {
      "id":this.id,
      "nomi":this.nomi,
      "regId":this.regId,
      "regNomi":this.regNomi,
      "qarzi":this.qarzi,
    };
  }

  DokonModel.fromJson(Map<String, dynamic> json){
    id = json['dokon_id'];
    nomi = json['dokon_nomi'];
    regId = json['region_id'];
    regNomi = json['reg_nomi'];
    qarzi = json['qarzi'];
  }
}