class GruppaModel {
  String? id;
  String? nomi;

  GruppaModel(this.id, this.nomi);

  Map<String, dynamic> toJson(){
    return {
      "id":this.id,
      "nomi":this.nomi
    };
  }

  GruppaModel.fromJson(Map<String, dynamic> json){
    id = json['gruppa_id'];
    nomi = json['nomi'];
  }
}