class UserModel {
  String? Id;
  String? user_id;
  String? fio;
  String? telefon;
  String? parol;
  String? holati;
  String? message;
  String? response;
  bool? success;

  UserModel(
      {
        required Id,
        required user_id,
        required fio,
        required telefon,
        required parol,
        required holati,
        required message,
        required success,
        required response
      })
  {
    this.Id = Id;
    this.user_id = user_id;
    this.fio = fio;
    this.telefon = telefon;
    this.parol = parol;
    this.holati = holati;
    this.message = message;
    this.success = success;
    this.response = response;
  }

  UserModel.fromJson(Map<String, dynamic> json){
    Id = json['Id'];
    user_id = json['user_id'];
    fio = json['fio'];
    telefon = json['telefon'];
    parol = json['parol'];
    holati = json['holati'];
    message = json['message'];
    success = json['success'];
    response = json['response'];
  }

}