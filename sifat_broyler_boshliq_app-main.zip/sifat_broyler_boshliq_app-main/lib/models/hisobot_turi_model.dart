class HisobotTuriModel {
  String? id;
  String? nomi;
  bool sana_1 = true;
  bool sana_2 = true;
  bool mijoz = false;
  bool yuk_beruvchi = false;
  bool agent = false;
  bool ombor = false;
  bool mahsulot_turi = false;
  bool mahsulot = false;

  bool is_required_mijoz = false;
  bool is_required_yuk_beruvchi = false;
  bool is_required_agent = false;

  HisobotTuriModel(
      this.id,
      this.nomi,
      this.sana_1,
      this.sana_2,
      this.mijoz,
      this.yuk_beruvchi,
      this.agent,
      this.ombor,
      this.mahsulot_turi,
      this.mahsulot);


}