class AgentModel {
  String? id;
  String? nomi;

  AgentModel(this.id, this.nomi);

  Map<String, dynamic> toJson(){
    return {
      "id":this.id,
      "nomi":this.nomi
    };
  }

  AgentModel.fromJson(Map<String, dynamic> json){
    id = json['agent_id'];
    nomi = json['nomi'];
  }
}