class TovarModel {
  String? id;
  String? brend_id;
  String? nomi;
  String? narxi;
  String? qoldiq;


  TovarModel(this.id, this.nomi, this.brend_id, this.narxi, this.qoldiq);

  Map<String, dynamic> toJson(){
    return {
      "id":this.id,
      "nomi":this.nomi,
      "brend_id":this.brend_id,
      "narxi":this.narxi,
      "qoldiq":this.qoldiq,
    };
  }

  TovarModel.fromJson(Map<String, dynamic> json){
    id = json['tovar_id'];
    nomi = json['nomi'];
    narxi = json['narxi'];
    brend_id = json['brend_id'];
    qoldiq = json['qoldiq'];
  }
}