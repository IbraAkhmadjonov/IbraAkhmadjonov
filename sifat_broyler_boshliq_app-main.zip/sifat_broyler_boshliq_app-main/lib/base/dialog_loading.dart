import 'package:boshliq_app/base/custom_loader.dart';
import 'package:boshliq_app/base/show_custom_snackbar.dart';
import 'package:boshliq_app/controllers/all_data_controller.dart';
import 'package:boshliq_app/routes/route_helper.dart';
import 'package:boshliq_app/utils/app_constants.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/widgets/app_text_field.dart';
import 'package:boshliq_app/widgets/big_text.dart';
import 'package:boshliq_app/widgets/dialog_frame.dart';
import 'package:boshliq_app/widgets/edit_text_field.dart';
import 'package:boshliq_app/widgets/small_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:money_formatter/money_formatter.dart';

class DialogLoading extends StatefulWidget {

  String text;
   DialogLoading({Key? key, this.text = "Ma'lumotlar yuklanmoqda..."}) : super(key: key);

  @override
  State<DialogLoading> createState() => _DialogLoadingState();
}

class _DialogLoadingState extends State<DialogLoading> {
  var kursController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AllDialogSkeleton(
        title: "",
        // icon: Icons.refresh,
        isExpanded: false,
        child: GetBuilder<AllDataController>(builder: (allDataController){
          return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomLoader(text: widget.text, sizeCircle: Dimensions.height20*3,),
                SizedBox(height: Dimensions.height20,)
              ]
          );
        })
    );
  }
}
