import 'package:boshliq_app/widgets/big_text.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
void showCustomSnackbar(String message, {bool isError=true,
  String title="Error",
  Color colorBackground = Colors.redAccent,
  Color colorTitle = Colors.white,
  Color colorText = Colors.white,
}){
  Get.snackbar(title, message,
      titleText: BigText(text: title,color: colorTitle,),
      messageText: Text(message, style: TextStyle(
          color: colorText
      ),
      ),
      colorText: colorText,
      snackPosition: SnackPosition.TOP,
      backgroundColor: colorBackground
  );
}