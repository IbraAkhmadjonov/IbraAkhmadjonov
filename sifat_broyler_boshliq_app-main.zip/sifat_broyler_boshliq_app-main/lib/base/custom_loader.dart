import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/widgets/small_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CustomLoader extends StatelessWidget {

  double sizeCircle;
  String text;
  CustomLoader({Key? key, this.sizeCircle = 0, this.text = "Ma'lumotlar yuklanmoqda..."}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          Container(
            height: sizeCircle == 0 ? Dimensions.height20*5 : sizeCircle,
            width: sizeCircle == 0 ? Dimensions.height20*5 : sizeCircle,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular((sizeCircle == 0 ? Dimensions.height20*5 : sizeCircle) /2),
                color: AppColors.mainColor
            ),
            alignment: Alignment.center,
            child:SizedBox(height: (sizeCircle == 0 ? Dimensions.height20*5 : sizeCircle) /2,
                width: (sizeCircle == 0 ? Dimensions.height20*5 : sizeCircle) /2,
                child: CircularProgressIndicator(color: Colors.white, )),

          ),
          SizedBox(height: Dimensions.height20,),
          SmallText(text: text,
            color: Colors.grey,
            size: Dimensions.font16,)
        ],
      ),
    );
  }
}