import 'package:boshliq_app/models/dokon_model.dart';
import 'package:boshliq_app/pages/home/dialogs/dialog_qidirish.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/decimal_formatter.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/utils/type_of_combo_enum.dart';
import 'package:boshliq_app/widgets/small_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

class EditTextField extends StatefulWidget {

  String title;
  String hint;
  IconData icon;
  final TextEditingController textController;
  final TextInputType keyBoardType;
  bool isNumberFormat;

  EditTextField({Key? key,
          required this.title,
          required this.hint,
          required this.icon,
          required this.textController,
          this.keyBoardType = TextInputType.text,
    this.isNumberFormat = false
  }) : super(key: key);

  @override
  State<EditTextField> createState() => _EditTextFieldState();
}

class _EditTextFieldState extends State<EditTextField> {

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Row(
        children: [
          Column(
            children: [
              SizedBox(height: Dimensions.height15,),
              SizedBox(
                  height: Dimensions.height20*2.5,
                  width: Dimensions.width30+Dimensions.width10,
                  child: Icon(widget.icon, size: Dimensions.height15*2,color: AppColors.mainColor,)),
            ],
          ),
          SizedBox(width: Dimensions.width10/2,),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SmallText(text: widget.title,
                  size: Dimensions.font12,
                  color: AppColors.mainColor,),
                SizedBox(height: Dimensions.height10/3,),
                Container(
                  height: Dimensions.height20*2,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(Dimensions.radius20/2),
                  ),
                  child: Center(
                    child: TextField(
                      textAlign: TextAlign.left,
                      controller: widget.textController,
                      keyboardType: widget.keyBoardType,
                      style: TextStyle(
                        fontSize: Dimensions.font16,
                        fontWeight: FontWeight.w600
                      ),
                      inputFormatters: [
                        if(widget.isNumberFormat)
                          ThousandsSeparatorInputFormatter()
                      ],
                      decoration: InputDecoration(
                        contentPadding: EdgeInsets.symmetric(horizontal: Dimensions.width10, vertical: 0),
                        hintText: widget.hint,
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(Dimensions.radius20/2),
                              borderSide: const BorderSide(
                                  width: 0,
                                  color: Colors.white
                              )
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(Dimensions.radius20/2),
                              borderSide: const BorderSide(
                                  width: 0,
                                  color: Colors.white
                              )
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(Dimensions.radius20/2),
                          )
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),

        ],
      ),
    );
  }
}
