import 'dart:ui';

import 'package:boshliq_app/controllers/all_data_controller.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AllDialogSkeleton extends StatefulWidget {
  final Widget child;
  final String title;
  final IconData? icon;
  final bool isExpanded;

  const AllDialogSkeleton({
    Key? key,
    required this.child,
    required this.title,
    this.icon,
    required this.isExpanded,
  }) : super(key: key);

  @override
  State<AllDialogSkeleton> createState() => _AllDialogSkeletonState();
}

class _AllDialogSkeletonState extends State<AllDialogSkeleton> {
  @override
  Widget build(BuildContext context) {
    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: Dimensions.height10),
        child: Dialog(
          clipBehavior: Clip.none,
          alignment: Alignment.center,
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(Dimensions.radius20)),
          insetPadding: EdgeInsets.symmetric(vertical: Dimensions.height20, horizontal: 0),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration:
            BoxDecoration(borderRadius: BorderRadius.circular(Dimensions.radius20)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Icon(widget.icon,
                        color: AppColors.mainColor, size: Dimensions.height20),
                    SizedBox(width: Dimensions.width10),
                    Expanded(
                      child: Text(widget.title, style: TextStyle(fontSize: Dimensions.font16,color: AppColors.mainColor)),
                    ),
                    InkResponse(
                      overlayColor:
                      MaterialStateProperty.all(Colors.transparent),
                      borderRadius: BorderRadius.circular(Dimensions.radius20),
                      onTap: () => {
                        Get.find<AllDataController>().ended = false,
                        Navigator.pop(context),
                      },
                      child: Padding(
                        padding: EdgeInsets.only(left: Dimensions.width20, bottom: Dimensions.height20, top: Dimensions.height10, right: Dimensions.width10),
                        child: Icon(Icons.close,
                            size: Dimensions.height20),
                      ),
                    ),
                  ],
                ),
                widget.isExpanded? Expanded(child: widget.child): widget.child,
              ],
            ),
          ),
        ),
      ),
    );
  }
}
