import 'dart:convert';
import 'package:boshliq_app/base/custom_loader.dart';
import 'package:boshliq_app/base/show_custom_snackbar.dart';
import 'package:boshliq_app/controllers/all_data_controller.dart';
import 'package:boshliq_app/models/hisobot_turi_model.dart';
import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/widgets/app_bar_widget.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:get/get.dart';

class WebViewPage extends StatefulWidget {
  final String title;
  final String sorovIzox;
  final HisobotTuriModel hisobotTuriModel;
  final String htmlString;
  const WebViewPage({Key? key,
    required this.sorovIzox,
    required this.hisobotTuriModel,
    required this.htmlString,
    required this.title})
      : super(key: key);

  @override
  _WebViewPageState createState() => _WebViewPageState();
}

class _WebViewPageState extends State<WebViewPage> {

  WebViewController? _controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }
  
  @override
  Widget build(BuildContext context) {

    String fileText = widget.htmlString
        .replaceAll("\n", " ")
        .replaceAll("\\", "")
        .replaceAll("`", "\"");

    _controller = WebViewController()..enableZoom(true)..loadHtmlString(fileText);

    return GetBuilder<AllDataController>(builder: (allDataController){
      
      return SafeArea(
        child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            backgroundColor: AppColors.mainColor,
            elevation: 0,
            toolbarHeight: Dimensions.height15*3,
            automaticallyImplyLeading: false,
            centerTitle: true,
            leading: IconButton(
              highlightColor: Colors.transparent,
              splashColor: Colors.transparent,
              padding: EdgeInsets.only(left: Dimensions.width20),
              onPressed: () {
                allDataController.ended = false;
                Navigator.pop(context);
              },
              icon: const Icon(Icons.arrow_back_ios),
            ),
            title: Text(
              widget.title,
              style:
              TextStyle( fontSize: Dimensions.font16, fontFamily: 'Medium'),
            ),
          ),
          body: allDataController.isLoading? CustomLoader():WebViewWidget(
            controller: _controller!,
          ),
        ),
      );
    });
  }
}
