import 'package:boshliq_app/utils/colors.dart';
import 'package:boshliq_app/utils/dimensions.dart';
import 'package:boshliq_app/widgets/small_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomeMenuButton extends StatelessWidget {

  IconData icon;
  String text;
  Function onTapFunction;

  HomeMenuButton({Key? key,
    required this.icon,
    required this.text,
    required this.onTapFunction}) : super(key: key);



  @override
  Widget build(BuildContext context) {
    return Container(
      child: InkWell(
        onTap: (){
          onTapFunction();
        },
        child: Container(
          width: Dimensions.mainCardViewWidth,
          height: Dimensions.mainCardViewHeight,
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(Dimensions.radius15)
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon,
                color: AppColors.mainColor,
                size: Dimensions.iconSize24*2,
              ),
              SizedBox(height: Dimensions.height10/2,),
              SmallText(text: text, size: Dimensions.font16, color:Colors.black,)
            ],
          ),
        ),
      ),
    );
  }
}
