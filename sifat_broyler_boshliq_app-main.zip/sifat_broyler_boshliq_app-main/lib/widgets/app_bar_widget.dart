// ignore_for_file: file_names

import 'package:boshliq_app/utils/dimensions.dart';
import 'package:flutter/material.dart';

import '../utils/app_constants.dart';

AppBar appBarWidget(BuildContext context, String title, Color color,
    [PreferredSizeWidget? bottom]) {
  return AppBar(
    backgroundColor: color,
    elevation: 0,
    toolbarHeight: Dimensions.height15*3,
    automaticallyImplyLeading: false,
    centerTitle: true,
    leading: IconButton(
      highlightColor: Colors.transparent,
      splashColor: Colors.transparent,
      padding: EdgeInsets.only(left: Dimensions.width20),
      onPressed: () {
        Navigator.pop(context);
      },
      icon: Icon(Icons.arrow_back_ios),
    ),
    title: Text(
      title,
      style:
          TextStyle( fontSize: Dimensions.font16, fontFamily: 'Medium'),
    ),
  );
}
